<?php
namespace Bitfoundry\Zapperpay\Block\Zapperpay;

use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Bitfoundry\Zapperpay\Model\Config;
use Bitfoundry\Zapperpay\Model\Zapperpay\Checkout;

class Form extends \Magento\Payment\Block\Form
{
    protected $_methodCode = Config::METHOD_CODE;
    protected $_zapperpayData;
    protected $zapperpayConfigFactory;
    protected $_localeResolver;
    protected $_config;
    protected $_isScopePrivate;
    protected $currentCustomer;

    public function __construct(
        Context $context,
        \Bitfoundry\Zapperpay\Model\ConfigFactory $zapperpayConfigFactory,
        ResolverInterface $localeResolver,
        \Bitfoundry\Zapperpay\Helper\Data $zapperpayData,
        CurrentCustomer $currentCustomer,
        array $data = []
    ) {
        $this->_zapperpayData       = $zapperpayData;
        $this->zapperpayConfigFactory = $zapperpayConfigFactory;
        $this->_localeResolver      = $localeResolver;
        $this->_config              = null;
        $this->_isScopePrivate      = true;
        $this->currentCustomer      = $currentCustomer;
        parent::__construct( $context, $data );
    }

    protected function _construct()
    {
        $this->_config = $this->zapperpayConfigFactory->create()->setMethod( $this->getMethodCode() );
        parent::_construct();
    }

    public function getMethodCode()
    {
        return $this->_methodCode;
    }

}
