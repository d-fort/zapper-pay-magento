<?php
namespace Bitfoundry\Zapperpay\Block\Payment;

class Scan extends \Magento\Framework\View\Element\Template
{
    protected $_paymentMethod;
    protected $_orderFactory;
    protected $_checkoutSession;
    protected $readFactory;
    protected $reader;
    protected $_assetRepo;
    protected $_storeManager;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Filesystem\Directory\ReadFactory $readFactory
     * @param \Magento\Framework\Module\Dir\Reader $reader
     * @param \Bitfoundry\Zapperpay\Model\Zapperpay $paymentMethod
     * @param \Magento\Framework\View\Asset\Repository $assetRepo
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Filesystem\Directory\ReadFactory $readFactory,
        \Magento\Framework\Module\Dir\Reader $reader,
        \Bitfoundry\Zapperpay\Model\Zapperpay $paymentMethod,
        \Magento\Framework\View\Asset\Repository $assetRepo,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->_orderFactory    = $orderFactory;
        $this->_checkoutSession = $checkoutSession;
        parent::__construct( $context, $data );
        $this->_isScopePrivate = true;
        $this->readFactory     = $readFactory;
        $this->reader          = $reader;
        $this->_paymentMethod  = $paymentMethod;
        $this->_assetRepo      = $assetRepo;
        $this->_storeManager   = $storeManager;
    }

    public function _prepareLayout()
    {
        $zapperData = $this->_paymentMethod->getZapperData();

        $this->setAppName($zapperData['appName'])
            ->setMerchantId($zapperData['merchantId'])
            ->setSiteId($zapperData['siteId'])
            ->setAmount($zapperData['amount'])
            ->setAmountType($zapperData['amountType'])
            ->setTip($zapperData['tip'])
            ->setMerchantReference($zapperData['merchantReference'])
            ->setShortMerchantName($zapperData['shortMerchantName'])
            ->setCurrencyISOCode($zapperData['currencyISOCode'])
            ->setUrl($zapperData['url'])
            ->setOrderId($zapperData['orderId'])
            ->setLoadingImg($this->_assetRepo->getUrl('Bitfoundry_Zapperpay::images/ajax-loader.gif'))
            ->setBaseUrl($this->_storeManager->getStore()->getBaseUrl());

        parent::_prepareLayout();
    }
}
