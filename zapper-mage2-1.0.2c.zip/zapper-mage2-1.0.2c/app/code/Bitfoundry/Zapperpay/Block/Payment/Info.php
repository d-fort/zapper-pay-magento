<?php
namespace Bitfoundry\Zapperpay\Block\Payment;

class Info extends \Magento\Payment\Block\Info
{
    protected $_ZapperpayInfoFactory;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Payment\Model\Config $paymentConfig
     * @param \Bitfoundry\Zapperpay\Model\InfoFactory $ZapperpayInfoFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Payment\Model\Config $paymentConfig,
        \Bitfoundry\Zapperpay\Model\InfoFactory $ZapperpayInfoFactory,
        array $data = []
    ) {
        $this->_ZapperpayInfoFactory = $ZapperpayInfoFactory;
        parent::__construct( $context, $data );
    }
    
    protected function _prepareSpecificInformation($transport = null)
    {
        $transport = parent::_prepareSpecificInformation($transport);
        $payment = $this->getInfo();
        $zapperpayInfo = $this->_ZapperpayInfoFactory->create();
        $info = $zapperpayInfo->getPaymentInfo($payment, true);

        return $transport->addData($info);
    }
}
