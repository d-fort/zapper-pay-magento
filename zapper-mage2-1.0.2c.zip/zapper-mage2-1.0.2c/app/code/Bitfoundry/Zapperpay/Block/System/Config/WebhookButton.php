<?php
namespace Bitfoundry\Zapperpay\Block\System\Config;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class WebhookButton extends Field
{
    protected $_template = 'Bitfoundry_Zapperpay::system/config/webhook_button.phtml';
    protected $_paymentMethod;
    protected $zapperData;
    protected $zapperpayHelper;

    public function __construct(
        Context $context,
        \Bitfoundry\Zapperpay\Model\Zapperpay $paymentMethod,
            \Bitfoundry\Zapperpay\Helper\Data $zapperpayHelper,
        array $data = []
    ) {
        $this->_paymentMethod  = $paymentMethod;
        $this->zapperpayHelper = $zapperpayHelper;       
        parent::__construct($context, $data);
    }

    public function render(AbstractElement $element)
    {
        $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();
        return parent::render($element);
    }

    protected function _getElementHtml(AbstractElement $element)
    {
        $helper = $this->zapperpayHelper;
        
        $this->setAppName($this->_paymentMethod->getConfigData('app_name'))
            ->setMerchantId($this->_paymentMethod->getConfigData('merchant_id'))
            ->setSiteId($this->_paymentMethod->getConfigData('site_id'))
            ->setPOSKey($this->_paymentMethod->getConfigData('pos_key'))
            ->setPOSId($this->_paymentMethod->getConfigData('pos_id'))
            ->setPOSVersion('1.0')
            ->setSignature($helper->createSecuritySignature($this->_paymentMethod->getConfigData('pos_secret'), $this->_paymentMethod->getConfigData('pos_key')))
            ->setBaseUrl($this->_storeManager->getStore()->getBaseUrl());
        
        return $this->_toHtml();
    }
    
    public function getAjaxOTPUrl()
    {
        $merchantId = $this->_paymentMethod->getConfigData('merchant_id');
        $siteId = $this->_paymentMethod->getConfigData('site_id');
        $zapperUrl = "https://zapapi.zapzap.mobi/zapperpointofsale/api/v2/merchants/$merchantId/sites/$siteId/onetimepins";
        return $zapperUrl;
    }
    
    public function getAjaxSetupWebhookUrl()
    {
        $baseURL = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
        $merchantId = $this->_paymentMethod->getConfigData('merchant_id');
        $siteId = $this->_paymentMethod->getConfigData('site_id');
        $magePaymentUrl = urlencode($baseURL . "zapperpay/scan/webhook");
        $zapperUrl = "https://zapapi.zapzap.mobi/zapperpointofsale/api/v2/merchants/$merchantId/sites/$siteId/paymentconfigurations?url=$magePaymentUrl&onetimepin="; // pin handled in button.phtml with javascript

        return $zapperUrl;
    }

    public function getAjaxUrl()
    {
        return $this->getUrl('zapperpay_admin/system_config/webhooksetup');
    }

    public function getButtonHtml()
    {
        $button = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        )->setData(
            [
                'id' => 'webhook_button',
                'label' => __('Setup Webhook'),
            ]
        );

        return $button->toHtml();
    }
}