<?php
namespace Bitfoundry\Zapperpay\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected static $_shouldAskToCreateBillingAgreement = false;
    protected $_paymentData;
    private $methodCodes;
    private $configFactory;
    protected $_logger;
    protected $mobileDetect;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\BaseFactory $configFactory,
        \Bitfoundry\Zapperpay\Helper\MobileDetect $mobileDetect,
        array $methodCodes
    ) {
        $this->_logger = $context->getLogger();
        $this->_paymentData  = $paymentData;
        $this->methodCodes   = $methodCodes;
        $this->configFactory = $configFactory;
        $this->mobileDetect  = $mobileDetect;

        parent::__construct( $context );
    }

    public function shouldAskToCreateBillingAgreement()
    {
        return self::$_shouldAskToCreateBillingAgreement;
    }

    public function getBillingAgreementMethods( $store = null, $quote = null )
    {
        $result = [];
        foreach ( $this->_paymentData->getStoreMethods( $store, $quote ) as $method ) {
            if ( $method instanceof MethodInterface ) {
                $result[] = $method;
            }
        }

        return $result;
    }

    public function isMobile()
    {
        $mobileDetect = new $this->mobileDetect;

        if ($mobileDetect->isMobile()) {
            return true;
        }

        return false;
    }

    public function createSecuritySignature($posToken, $posKey)
    {
        $plainValue = strtoupper($posToken . "&" . $posKey);
        $buffer = mb_convert_encoding($plainValue, "ASCII");
        $hash = hash('sha256', $buffer, false);
        $hash = str_replace("-", "", $hash);

        return $hash;
    }

    public function getIp()
    {
        //Just get the headers if we can or else use the SERVER global
        if ( function_exists( 'apache_request_headers' ) ) {
            $headers = apache_request_headers();
        } else {
            $headers = $_SERVER;
        }
        //Get the forwarded IP if it exists
        if ( array_key_exists( 'X-Forwarded-For', $headers ) && filter_var( $headers['X-Forwarded-For'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            $the_ip = $headers['X-Forwarded-For'];
        } elseif ( array_key_exists( 'HTTP_X_FORWARDED_FOR', $headers ) && filter_var( $headers['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 )
        ) {
            $the_ip = $headers['HTTP_X_FORWARDED_FOR'];
        } else {
            $the_ip = filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
        }

        return $the_ip;
    }
}
