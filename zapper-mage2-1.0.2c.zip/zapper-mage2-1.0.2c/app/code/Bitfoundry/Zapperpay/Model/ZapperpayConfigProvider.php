<?php
namespace Bitfoundry\Zapperpay\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Payment\Helper\Data as PaymentHelper;
use Bitfoundry\Zapperpay\Helper\Data as ZapperpayHelper;

class ZapperpayConfigProvider implements ConfigProviderInterface
{
    //const CODE = 'zapperpay';
    /**
     * @var ResolverInterface
     */
    protected $localeResolver;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var \Magento\Customer\Helper\Session\CurrentCustomer
     */
    protected $currentCustomer;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var ZapperpayHelper
     */
    protected $zapperpayHelper;

    /**
     * @var string[]
     */
     protected $methodCodes = [
         Config::METHOD_CODE,
     ];

    /**
     * @var \Magento\Payment\Model\Method\AbstractMethod[]
     */
    protected $methods = [];

    /**
     * @var PaymentHelper
     */
    protected $paymentHelper;

    /**
     * @param ConfigFactory $configFactory
     * @param ResolverInterface $localeResolver
     * @param CurrentCustomer $currentCustomer
     * @param ZapperpayHelper $paymentHelper
     * @param PaymentHelper $paymentHelper
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        ConfigFactory $configFactory,
        ResolverInterface $localeResolver,
        CurrentCustomer $currentCustomer,
        ZapperpayHelper $zapperpayHelper,
        PaymentHelper $paymentHelper
    ) {
        $this->_logger = $logger;
        $this->localeResolver  = $localeResolver;
        $this->config          = $configFactory->create();
        $this->currentCustomer = $currentCustomer;
        $this->zapperpayHelper = $zapperpayHelper;
        $this->paymentHelper   = $paymentHelper;

        foreach ( $this->methodCodes as $code ) {
            $this->methods[$code] = $this->paymentHelper->getMethodInstance( $code );
        }
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $config = [
            'payment' => [
                'zapperpay' => [
                    'paymentAcceptanceMarkSrc'  => $this->config->getPaymentMarkImageUrl(),
                    'paymentAcceptanceMarkHref' => $this->config->getPaymentMarkWhatIsZapper(),
                    'paymentInstructions'       => $this->config->getPaymentInstructions(),
                ],
            ],
        ];

        foreach ( $this->methodCodes as $code ) {
            if ( $this->methods[$code]->isAvailable() ) {
                $config['payment']['zapperpay']['redirectUrl'][$code]          = $this->getMethodRedirectUrl( $code );
                $config['payment']['zapperpay']['billingAgreementCode'][$code] = $this->getBillingAgreementCode( $code );
            }
        }

        return $config;
    }

    /**
     * Return redirect URL for method
     *
     * @param string $code
     * @return mixed
     */
    protected function getMethodRedirectUrl( $code )
    {
        $methodUrl = $this->methods[$code]->getCheckoutRedirectUrl();
        return $methodUrl;
    }

    /**
     * Return billing agreement code for method
     *
     * @param string $code
     * @return null|string
     */
    protected function getBillingAgreementCode( $code )
    {
        $customerId = $this->currentCustomer->getCustomerId();
        $this->config->setMethod( $code );

        // Always return null
        return $this->zapperpayHelper->shouldAskToCreateBillingAgreement( $this->config, $customerId );
    }
}
