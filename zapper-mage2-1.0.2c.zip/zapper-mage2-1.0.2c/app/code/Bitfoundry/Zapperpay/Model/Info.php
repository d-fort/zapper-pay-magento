<?php
namespace Bitfoundry\Zapperpay\Model;

class Info
{
    public function getPaymentInfo(\Magento\Payment\Model\InfoInterface $payment, $labelValuesOnly = false)
    {
        $result = [];

        $order = $payment->getOrder();
        $order_id = $order->getId();

        $zapper_id = '';

        if ($order->hasInvoices()) {
            $oInvoiceCollection = $order->getInvoiceCollection();
            foreach ($oInvoiceCollection as $oInvoice) {
                $zapper_id = $oInvoice->getZapperId();
            }
        }

        if ($zapper_id) {
            // add zapper_id
            $label = __('Zapper ID');
            $value = $zapper_id;
            if ($labelValuesOnly) {
                $result[(string)$label] = $value;
            } else {
                $result['zapper_id'] = ['label' => $label, 'value' => $value];
            }
        }

        return $result;
    }
}
