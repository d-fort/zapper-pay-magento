<?php
namespace Bitfoundry\Zapperpay\Setup;
 
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
 
class InstallSchema implements InstallSchemaInterface {
 
    public function install (SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;
 
        $installer->startSetup();
        
        $tableName = $installer->getTable('sales_invoice');

        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableName) == true) {
            // Declare data
            $columns = [
                'zapper_id' => [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    30,
                    'nullable' => true,
                    'comment' => 'Unique Zapper transaction identifier for the customer',
                ],
            ];

            $connection = $installer->getConnection();

            foreach ($columns as $name => $definition) {
                $connection->addColumn($tableName, $name, $definition);
            }
        }
 
        $installer->endSetup();
    }
}