<?php
namespace Bitfoundry\Zapperpay\Controller\Adminhtml\System\Config;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;

class Webhooksetup extends Action
{
    protected $resultJsonFactory;
    
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory
    )
    {
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        return $result->setData(['success' => true]);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Bitfoundry_Zapperpay::config');
    }
}