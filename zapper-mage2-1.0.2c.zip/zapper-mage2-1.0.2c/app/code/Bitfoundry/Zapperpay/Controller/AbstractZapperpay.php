<?php
namespace Bitfoundry\Zapperpay\Controller;

use Magento\Checkout\Controller\Express\RedirectLoginInterface;
use Magento\Framework\App\Action\Action as AppAction;

abstract class AbstractZapperpay extends AppAction implements RedirectLoginInterface
{
    protected $_checkoutTypes = [];
    protected $_config;
    protected $_quote = false;
    protected $_configType = 'Bitfoundry\Zapperpay\Model\Config';
    protected $_configMethod = \Bitfoundry\Zapperpay\Model\Config::METHOD_CODE;
    protected $_checkoutType;
    protected $_customerSession;
    protected $_checkoutSession;
    protected $_orderFactory;
    protected $order;
    protected $zapperpaySession;
    protected $_paymentMethod;
    protected $helper;
    protected $_urlHelper;
    protected $_customerUrl;
    protected $_logger;
    protected $_order;
    protected $pageFactory;
    protected $_transactionFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Magento\Framework\Session\Generic $zapperpaySession,
        \Bitfoundry\Zapperpay\Model\Zapperpay $paymentMethod,
        \Bitfoundry\Zapperpay\Helper\Data $helper,
        \Magento\Framework\Url\Helper\Data $urlHelper,
        \Magento\Customer\Model\Url $customerUrl,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\DB\TransactionFactory $transactionFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->_logger                  = $logger;
        $this->_customerSession         = $customerSession;
        $this->_checkoutSession         = $checkoutSession;
        $this->_orderFactory            = $orderFactory;
        $this->order                    = $order;
        $this->zapperpaySession         = $zapperpaySession;
        $this->_paymentMethod           = $paymentMethod;
        $this->helper                   = $helper;
        $this->_urlHelper               = $urlHelper;
        $this->_customerUrl             = $customerUrl;
        $this->pageFactory              = $pageFactory;
        $this->_transactionFactory      = $transactionFactory;
        $this->messageManager           = $messageManager;

        parent::__construct($context);

        $parameters    = ['params' => [$this->_configMethod]];
        $this->_config = $this->_objectManager->create( $this->_configType, $parameters );
    }

    public function getConfigData($field)
    {
        return $this->_paymentMethod->getConfigData($field);
    }

    protected function _initCheckout()
    {
        $this->_order = $this->_checkoutSession->getLastRealOrder();

        if ( !$this->_order->getId() ) {
            $this->getResponse()->setStatusHeader( 404, '1.1', 'Not found' );
            throw new \Magento\Framework\Exception\LocalizedException( __( 'We could not find "Order" for processing' ) );
        }

        if ( $this->_order->getState() != \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT ) {
            $this->_order->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)->save();
        }

        if ( $this->_order->getQuoteId() ) {
            $this->_checkoutSession->setZapperpayQuoteId( $this->_checkoutSession->getQuoteId() );
            $this->_checkoutSession->setZapperpayeSuccessQuoteId( $this->_checkoutSession->getLastSuccessQuoteId() );
            $this->_checkoutSession->setZapperpayRealOrderId( $this->_checkoutSession->getLastRealOrderId() );
            $this->_checkoutSession->getQuote()->setIsActive( false )->save();
        }
    }

    protected function _getSession()
    {
        return $this->zapperpaySession;
    }


    protected function _getCheckoutSession()
    {
        return $this->_checkoutSession;
    }

    protected function _getQuote()
    {
        if ( !$this->_quote ) {
            $this->_quote = $this->_getCheckoutSession()->getQuote();
        }

        return $this->_quote;
    }

    public function getCustomerBeforeAuthUrl()
    {
        return;
    }

    public function getActionFlagList()
    {
        return [];
    }

    public function getLoginUrl()
    {
        return $this->_customerUrl->getLoginUrl();
    }

    public function getRedirectActionName()
    {
        return 'index';
    }

    public function redirectLogin()
    {
        $this->_actionFlag->set( '', 'no-dispatch', true );
        $this->_customerSession->setBeforeAuthUrl( $this->_redirect->getRefererUrl() );
        $this->getResponse()->setRedirect(
            $this->_urlHelper->addRequestParam( $this->_customerUrl->getLoginUrl(), ['context' => 'checkout'] )
        );
    }

    public function getOrderByZapperReference($orderRef) {
        $order = $this->order->loadByIncrementId($orderRef);
        return $order;
    }
}
