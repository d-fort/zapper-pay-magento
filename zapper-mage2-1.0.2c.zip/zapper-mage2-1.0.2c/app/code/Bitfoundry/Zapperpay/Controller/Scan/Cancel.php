<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Event\ObserverInterface;

class Cancel extends Action
{
    protected $resultPageFactory;
    protected $orderManagement;
    protected $_messageManager;
    protected $_eventManager;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Magento\Sales\Api\OrderManagementInterface $orderManagement,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Event\Manager $eventManager
    )
    {
        parent::__construct($context);
        $this->_resultLayoutFactory     = $resultLayoutFactory;
        $this->orderManagement          = $orderManagement;
        $this->_checkoutSession         = $checkoutSession;
        $this->_messageManager          = $messageManager;
        $this->_eventManager            = $eventManager;
    }

    public function execute()
    {
        $this->_order = $this->_checkoutSession->getLastRealOrder();
        $this->orderManagement->cancel($this->_order->getId());

        $this->_messageManager->addWarningMessage('Order cancelled.');
        $this->_eventManager->dispatch('order_cancel_after', ['order' => $this->_order]);

        $this->_redirect('checkout/cart', array('_secure'=> true));

        return '';
    }
}
