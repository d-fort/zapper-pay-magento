<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;
        
class Simulatepayment extends \Bitfoundry\Zapperpay\Controller\AbstractZapperpay
{    
    public function execute()
    {
        $data = array(
            "Reference"=>"",
            "PaymentStatusId"=>2,
            "PosReference"=>"fvnla7on96ixjemi",
            "PSPData"=>"",
            "Amount"=>"290.00",
            "ZapperId"=>"VENEE4RJ3E9749NQ3J",
            "UpdatedDate"=>"2018-03-01T13:11:32.32",
            "TipAmount"=>"0.00",
            "VoucherAmount"=>"0.00",
            "ZapperDiscountAmount"=>"0.00",
            "InvoiceAmount"=>"290.00",
            "Vouchers"=>[],
            "CustomFields"=>[]
        );

        //$url_send ="http://magento2.zapperops.net/zapperpay/scan/webhook";
        $url_send ="http://dev.magento22.local/zapperpay/scan/webhook";
        $str_data = json_encode($data);

        function sendPostData($url, $post){
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            return $result;
        }

        echo " " . sendPostData($url_send, $str_data);
        
        return '';
    }
}
