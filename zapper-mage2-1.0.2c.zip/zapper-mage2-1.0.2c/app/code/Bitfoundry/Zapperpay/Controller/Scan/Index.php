<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

use Magento\Framework\App\Action\Action;

class Index extends Action
{
    protected $_resultLayoutFactory;
    protected $_zapperpayHelper;
    protected $_zapperpay;
    protected $_logger;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Bitfoundry\Zapperpay\Helper\Data $zapperpayHelper,
        \Bitfoundry\Zapperpay\Model\Zapperpay $zapperpay,
        \Psr\Log\LoggerInterface $logger
    )
    {
        parent::__construct($context);
        $this->_resultLayoutFactory = $resultLayoutFactory;
        $this->_zapperpayHelper = $zapperpayHelper;
        $this->_zapperpay = $zapperpay;
        $this->_logger = $logger;
    }

    public function execute()
    {
        // check for mobile device, if found send to zapper app (deeplink)
        if ($this->_zapperpayHelper->isMobile()) {
            $zapperData = $this->_zapperpay->getZapperData();
            $urlParams = $zapperData['url'];

            header("Location:https://www.zapper.com/payWithZapper?qr=" . $urlParams);
            die();
        }

        $resultLayout = $this->_resultLayoutFactory->create();
        $block = $resultLayout->getLayout()->getBlock('zapperpay');
        echo $block->setTemplate('Bitfoundry_Zapperpay::scan.phtml')->toHtml();
    }
}
