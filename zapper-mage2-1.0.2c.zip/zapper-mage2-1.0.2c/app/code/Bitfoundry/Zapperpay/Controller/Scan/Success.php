<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

class Success extends \Bitfoundry\Zapperpay\Controller\AbstractZapperpay
{
    public function execute()
    {
        try
        {
            $order = $this->_checkoutSession->getLastRealOrder();
            $key = $this->getRequest()->getParam('key');
            $orderId = $order->getId();
            $orderIdMd5 = md5($order->getIncrementId() + 55);

            //deeplinking success
            if ($this->getRequest()->getParam('deeplinkid') == $orderIdMd5) {
                // redirect to confirmation page to handle deeplinking success/failure
                $this->_redirect('zapperpay/scan/confirm', array('_secure'=> true));
            } // end if
            elseif ($key == $order->getIncrementId() . $orderId) {
                $zapperpay = $this->_paymentMethod;
                $zapperId = $this->getRequest()->getParam('zapperId');
                $paymentId = $this->getRequest()->getParam('paymentId');
                $matchingZapperId = false;

                $zapperConfirmationCode = $zapperpay->zapperConfirmation($paymentId);
                if ($zapperConfirmationCode == 2) {
                    if ($order->getBaseTotalDue() != 0) { // prevent double invoicing because of zapper's payment webhook
                        //check existing invoices for a matching zapperID
                        $invoiceCollection = $order->getInvoiceCollection();
                        foreach($invoiceCollection as $invoice) {
                            if ($invoice->getZapperId() == $zapperId) {
                                $matchingZapperId = true;
                                break;
                            }
                        }

                        if (!$matchingZapperId) {
                            $invoice = $order->prepareInvoice();
                            $invoice->setZapperId($zapperId);
                            $invoice->register()->capture();

                            $transaction = $this->_transactionFactory->create();
                            $transaction->addObject($invoice)
                                ->addObject($invoice->getOrder())
                                ->save();

                            $status = \Magento\Sales\Model\Order::STATE_PROCESSING;

                            $order->setStatus( $status ); //configure the status
                            $order->setState( $status )->save(); //try and configure the status
                            $order->addStatusHistoryComment(__( 'Invoice created #%1.', $invoice->getIncrementId()));
                            $order->setIsCustomerNotified(true);
                            $order->save();

                            $this->messageManager->addSuccessMessage('Zapper Payment Successful.');
                        }
                    }

                    $this->_redirect('checkout/onepage/success', array('_secure'=> true));
                } // end if
                elseif ($zapperConfirmationCode == 1 || $zapperConfirmationCode == 7 ) {
                    $status = \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT;
                    $order->setStatus($status);
                    $order->setState($status)->save();
                    $order->addStatusHistoryComment(__('Zapper payment pending/processing. ZAPPER STATUS CODE: ("%1")', $zapperConfirmationCode));
                    $order->save();
                    $this->_redirect('checkout/onepage/success', array('_secure'=> true));
                } // end if
                elseif ($zapperConfirmationCode == 4) {
                    // payment cancelled
                    $this->messageManager->addNotice('Zapper payment has been cancelled');
                    $order->registerCancellation('Redirect Response, Transaction has been cancelled.')->save();
                    $this->_checkoutSession->restoreQuote();
                    $this->_redirect('checkout/cart', array('_secure'=>true));
                }
                else {
                    $this->_redirect('checkout/onepage/failure', array('_secure'=> true));
                    $this->_logger->error("************************************************************************************");
                    $this->_logger->error("*    Payment Tampering");
                    $this->_logger->error("*    Looks like we have some payment redirect tampering on order: " . $order->getIncrementId() . ", key: " . $this->getRequest()->getParam('key') . ", zapper. ZAPPER STATUS CODE: ($zapperConfirmationCode)");
                    $this->_logger->error("************************************************************************************");
                }
            }
            else {
                $this->_redirect('checkout/onepage/failure', array('_secure'=> true));
                $this->_logger->error("************************************************************************************");
                $this->_logger->error("*    Payment Tampering");
                $this->_logger->error("*    Looks like we have some payment redirect tampering on order: " . $order->getIncrementId() . ", key: " . $this->getRequest()->getParam('key'));
                $this->_logger->error("************************************************************************************");
            }
        } catch ( \Magento\Framework\Exception\LocalizedException $e ) {
            $this->_logger->error($e->getMessage());
            $this->messageManager->addExceptionMessage($e, $e->getMessage());
            $this->_redirect('checkout/cart', array('_secure'=> true));
        } catch (\Exception $e) {
            $this->_logger->error($e->getMessage());
            $this->messageManager->addExceptionMessage($e, __('We can\'t start Zapper Checkout.'));
            $this->_redirect('checkout/cart', array('_secure'=> true));
        }

        return '';
    }
}
