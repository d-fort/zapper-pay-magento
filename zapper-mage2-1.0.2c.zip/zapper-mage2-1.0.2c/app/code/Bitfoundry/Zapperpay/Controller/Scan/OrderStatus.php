<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

class OrderStatus extends \Magento\Framework\App\Action\Action
{
    protected $jsonResultFactory;
    protected $_checkoutSession;
    protected $_orderFactory;
    protected $order;
    protected $zapperpaySession;
    protected $_paymentMethod;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Bitfoundry\Zapperpay\Model\Zapperpay $paymentMethod
    ) {
        parent::__construct($context);
        $this->jsonResultFactory        = $jsonResultFactory;
        $this->_checkoutSession         = $checkoutSession;
        $this->_orderFactory            = $orderFactory;
        $this->order                    = $order;
        $this->_paymentMethod           = $paymentMethod;
    }

    public function execute()
    {
        $order = $this->_checkoutSession->getLastRealOrder();
        $result = $this->jsonResultFactory->create();

        $result->setData(['order_status' => __($order->getStatus())]);
        return $result;
    }
}
