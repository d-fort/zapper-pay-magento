<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Event\ObserverInterface;

class Failure extends Action
{
    protected $resultPageFactory;
    protected $orderManagement;
    protected $_messageManager;
    protected $_eventManager;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Event\Manager $eventManager
    )
    {
        parent::__construct($context);
        $this->_resultLayoutFactory     = $resultLayoutFactory;
        $this->_checkoutSession         = $checkoutSession;
        $this->_messageManager          = $messageManager;
        $this->_eventManager            = $eventManager;
    }

    public function execute()
    {
        $this->_order = $this->_checkoutSession->getLastRealOrder();

        $message = __('Zapper payment failed.');
        if ($this->_order->getId() && $this->_order->getState() != \Magento\Sales\Model\Order::STATE_CANCELED) {
            $this->_order->registerCancellation($message)->save();
            $this->_eventManager->dispatch('order_cancel_after', ['order' => $this->_order]);
        }
        $this->_checkoutSession->restoreQuote();

        $this->_messageManager->addWarningMessage($message);

        $this->_redirect('checkout/cart', array('_secure'=> true));

        return '';
    }
}
