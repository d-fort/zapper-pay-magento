<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

class Webhook extends \Bitfoundry\Zapperpay\Controller\AbstractZapperpay
{
    public function execute()
    {
        $zapperpay = $this->_paymentMethod;
        $helper = $this->helper;
        $expectedIp = $zapperpay->getConfigData('expected_api_ip');

        if ($expectedIp == "" || $helper->getIp() == $expectedIp || $helper->getIp() == '127.0.0.1') {

            $data = json_decode(json_decode(file_get_contents('php://input')), true);
            //$data = json_decode(file_get_contents('php://input'), true); // simulated payments

            if ($data['Reference'] == '')
                $orderIdFromZapper = $data['PosReference']; // order id from deeplinking
            else
                $orderIdFromZapper = $data['Reference']; // order if from qr code scanning

            $order = $this->getOrderByZapperReference($orderIdFromZapper);
            $zapperId = $data['ZapperId'];
            $matchingZapperId = false;

            //payment success
            if ($data['PaymentStatusId'] == 2) {
                if ($order->getBaseTotalDue() != 0) { // prevent double invoicing
                    //check existing invoices for a matching zapperID
                    $invoiceCollection = $order->getInvoiceCollection();
                    foreach($invoiceCollection as $invoice) {
                        if ($invoice->getZapperId() == $zapperId) {
                            $matchingZapperId = true;
                            break;
                        }
                    }

                    if (!$matchingZapperId) {
                        $zapperConfirmationCode = $zapperpay->zapperConfirmation(0, $data['PosReference']);
                        if ($zapperConfirmationCode == 2) {
                            $invoice = $order->prepareInvoice();
                            $invoice->setZapperId($zapperId);
                            $invoice->register()->capture();

                            $transaction = $this->_transactionFactory->create();
                            $transaction->addObject($invoice)
                                ->addObject($invoice->getOrder())
                                ->save();

                            $status = \Magento\Sales\Model\Order::STATE_PROCESSING;

                            $order->setStatus( $status ); //configure the status
                            $order->setState( $status )->save(); //try and configure the status
                            $order->addStatusHistoryComment(__( 'Invoice created via the webhook, #%1.', $invoice->getIncrementId()));
                            $order->setIsCustomerNotified(true);
                            //$order->sendNewOrderEmail();
                            $order->save();

                            $this->messageManager->addSuccessMessage('Zapper Payment Successful.');

                            //$invoice->sendEmail(); // send after order save otherwise Invoice Number and date don't come through on email
                        } // end if
                        elseif ($zapperConfirmationCode == 1 || $zapperConfirmationCode == 7 ) {
                            $status = \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT;
                            $order->setStatus($status);
                            $order->setState($status)->save();
                            $order->addStatusHistoryComment(__('Zapper payment pending/processing. ZAPPER STATUS CODE: ("%1")', $zapperConfirmationCode));
                            $order->save();
                        } // end if
                        elseif ($zapperConfirmationCode == 4) {
                            // payment cancelled
                            $order->addStatusToHistory(Mage_Sales_Model_Order::STATE_CANCELED,'The user cancelled payment in Zapper.',false);
                            $order->save();
                        }
                        else {
                            $this->_logger->error("************************************************************************************");
                            $this->_logger->error("*    Payment Tampering");
                            $this->_logger->error("*    Looks like we have some payment redirect tampering on order: " . $order->getIncrementId() . ", key: " . $this->getRequest()->getParam('key') . ", zapper. ZAPPER STATUS CODE: ($zapperConfirmationCode)");
                            $this->_logger->error("************************************************************************************");
                        }
                    } // end if
                } // end if
            } // end if
            else {
                // payment failed
                $status = \Magento\Sales\Model\Order::STATE_CANCELED;
                $message = __('Zapper payment failed. Order cancelled, basket restored.');
                if ($order->getId() && $order->getState() != \Magento\Sales\Model\Order::STATE_CANCELED) {
                    $order->setStatus($status);
                    $order->setState($status)->save();
                    $order->addStatusHistoryComment(__('Payment declined via the Zapper app.'));
                    $order->registerCancellation($message)->save();
                }
            }
        }
        else {
            $this->_logger->error("************************************************************************************");
            $this->_logger->error("*    Unauthorized IP address trying to access zapper payment webhook: " . $helper->getIp());
            $this->_logger->error("************************************************************************************");
        }

        return '';
    }
}
