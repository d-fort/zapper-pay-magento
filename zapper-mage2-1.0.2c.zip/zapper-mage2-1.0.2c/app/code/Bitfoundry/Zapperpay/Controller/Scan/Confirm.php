<?php
namespace Bitfoundry\Zapperpay\Controller\Scan;

use Magento\Framework\App\Action\Action;

class Confirm extends Action
{
    protected $_resultLayoutFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory
    )
    {
        parent::__construct($context);
        $this->_resultLayoutFactory = $resultLayoutFactory;
    }

    public function execute()
    {
        $resultLayout = $this->_resultLayoutFactory->create();
        $block = $resultLayout->getLayout()->getBlock('zapperpay_confirm');
        echo $block->setTemplate('Bitfoundry_Zapperpay::confirm.phtml')->toHtml();
    }
}
